import React from 'react'
import { Form, Button } from 'semantic-ui-react';
import { User } from '@daml.js/create-daml-app';
import {Party} from '@daml/types';
import { userContext } from './App';

type Props = {
    partyToAlias: Map<string, string>;
}

/**
 * React component to edit a message to send to a follower.
 */
const MessageEdit: React.FC<Props> = ({partyToAlias}) => {
  const sender = userContext.useParty();
  const [receiver, setReceiver] = React.useState<Party | undefined>();
  const [content, setContent] = React.useState("");
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const friendships = userContext.useStreamQuery(User.Friendship).contracts.map(f => f.key)
  const ledger = userContext.useLedger();
  const getFriend = (f: User.Friendship.Key) => {
      return f._1 === sender ? f._2 : f._1
  };

  const submitMessage = async (event: React.FormEvent) => {
    try {
      event.preventDefault();
      if (receiver === undefined) {
        return;
      }
      setIsSubmitting(true);
      if (friendships.find(f => f._1 === sender && f._2 === receiver) !== undefined) {
        await ledger.exerciseByKey(User.Friendship.SendMessage1, {_1: sender, _2: receiver}, {content});
      } else {
        await ledger.exerciseByKey(User.Friendship.SendMessage2, {_1: receiver, _2: sender}, {content});
      }
      setContent("");
    } catch (error) {
      alert(`Error sending message:\n${JSON.stringify(error)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form onSubmit={submitMessage}>
      <Form.Dropdown
        selection
        className='test-select-message-receiver'
        placeholder="Select a follower"
        options={friendships.map((f: User.Friendship.Key) => ({ key: getFriend(f), text: partyToAlias.get(getFriend(f)) ?? getFriend(f), value: getFriend(f)}))}
        value={receiver}
        onChange={(event,data) => setReceiver(data.value?.toString())}
      />
      <Form.Input
        className='test-select-message-content'
        placeholder="Write a message"
        value={content}
        onChange={event => setContent(event.currentTarget.value)}
      />
      <Button
        fluid
        className='test-select-message-send-button'
        type="submit"
        disabled={isSubmitting || receiver === undefined || content === ""}
        loading={isSubmitting}
        content="Send"
      />
    </Form>
  );
};

export default MessageEdit;
