// Copyright (c) 2020 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React from 'react'
import { Form, List, Button, Icon } from 'semantic-ui-react';
import { Party } from '@daml/types';
import { User } from '@daml.js/create-daml-app';
import { userContext } from './App';

type Props = {
  friends: User.Friendship.Key[];
  onCancel: (friendship: User.Friendship.Key) => Promise<boolean>;
  onCreateFriendRequest: (friend: Party) => Promise<boolean>;
  partyToAlias: Map<Party, string>;
}

/**
 * React component to edit a list of `Party`s.
 */
const FriendList: React.FC<Props> = ({friends, onCreateFriendRequest, onCancel, partyToAlias}) => {
  const username = userContext.useParty();
  const [newParty, setNewParty] = React.useState<string | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const aliasToOption = (party: string, alias: string) => {
    return { key: party, text: alias, value: party };
  };
  const options = Array.from(partyToAlias.entries()).map(e =>
    aliasToOption(e[0], e[1]),
  );

  const addParty = async (event?: React.FormEvent) => {
    if (event) {
      event.preventDefault();
    }
    setIsSubmitting(true);
    const success = await onCreateFriendRequest(newParty ?? "");
    setIsSubmitting(false);
    if (success) {
      setNewParty('');
    }
  }

  const getFriend = (friendship: User.Friendship.Key) => {
    return friendship._1 === username ? friendship._2 : friendship._1
  }

  return (
    <List relaxed>
      {[...friends].map((friendship) =>
        <List.Item key={getFriend(friendship)}>
          <List.Icon name='user' />
          <List.Content>
            <List.Content floated='right'>
              <Icon
                name='cancel'
                link
                onClick={() => onCancel(friendship)} />
            </List.Content>
            <List.Header>
              {partyToAlias.get(getFriend(friendship)) ?? getFriend(friendship)}
            </List.Header>
        </List.Content>
        </List.Item>
      )}
      <br />
      <Form onSubmit={addParty}>
        <Form.Select
          fluid
          search
          allowAdditions
          additionPosition="bottom"
          readOnly={isSubmitting}
          loading={isSubmitting}
          className="test-select-follow-input"
          placeholder={newParty ?? "Username to create friend request for"}
          value={newParty}
          options={options}
          onAddItem={(event, { value }) => setNewParty(value?.toString())}
          onChange={(event, { value }) => setNewParty(value?.toString())}
        />
        <Button
          type='submit'
          >
          Create friend request
        </Button>
      </Form>
    </List>
  );
};

export default FriendList;
