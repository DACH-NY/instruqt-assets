import React from 'react';
import {List, Grid, Segment} from 'semantic-ui-react';
import InvoiceListItem from './InvoiceListItem';
import CreditListItem from './CreditListItem';
import {Invoice} from '@daml.js/market/lib/Market';
import * as damlTypes from '@daml/types';
import * as market from '@daml.js/market';
import { userContext } from './App';
import { Party } from '@daml/types';

type Props = {
  partyToAlias: Map<Party, string>;
}

const CreditDebitList: React.FC<Props> = ({partyToAlias}) => {
  const party = userContext.useParty();
  const invoices = userContext.useStreamQuery(market.Market.Invoice, () => ({obligor: party}), [party]);
  const credits = userContext.useStreamQuery(market.Market.Invoice, () => ({owner: party}), [party]);
  const ledger = userContext.useLedger();
  const handleConfirmPayment = async (contractId: damlTypes.ContractId<Invoice>) => {
    await ledger.exerciseByKey(market.Market.User.ConfirmPayment, party, {invoice: contractId});
    alert("Payment confirmed");
  }
  return (
    <Segment>
    <Grid columns={2}>
      <Grid.Column>
        <List divided relaxed>
          <List.Header>
            <h2> Debits </h2>
          </List.Header>
          {invoices.contracts.map(invoice =>
            <InvoiceListItem
                invoice={invoice.payload}
                onPay={() => alert('Payment not implemented yet.')}
                partyToAlias={partyToAlias}
            >
            </InvoiceListItem>
          )}
        </List>
      </Grid.Column>
      <Grid.Column>
        <List divided relaxed verticalAlign='middle'>
          <List.Item>
            <h2> Credits </h2>
          </List.Item>
            {credits.contracts.map(credit =>
              <CreditListItem
                credit={credit.payload}
                onConfirmPayment={() => handleConfirmPayment(credit.contractId)}
                partyToAlias={partyToAlias}
              >
              </CreditListItem>)
            }
        </List>
      </Grid.Column>
    </Grid>
    </Segment>
  )
};


export default CreditDebitList;
