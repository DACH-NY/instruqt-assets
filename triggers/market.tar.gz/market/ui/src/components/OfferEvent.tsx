import React from 'react';
import {Feed, Icon, Grid} from 'semantic-ui-react';
import { SellOffer } from '@daml.js/market/lib/Market';

type Props = {
  offer: SellOffer;
  handleTakeOffer: () => void;
}

export const OfferEvent: React.FC<Props> = ({offer, handleTakeOffer}) => {
    return (
      <Feed.Event>
        <Feed.Label>
          <Icon name='pencil'/>
        </Feed.Label>
        <Feed.Content>
          <Feed.Summary>
            <Feed.User> {offer.seller}</Feed.User>
            <Feed.Date> {offer.date} </Feed.Date>
            <Feed.Extra> {offer.title}</Feed.Extra>
          </Feed.Summary>
          <Feed.Extra>
            {offer.description}
          </Feed.Extra>
          <Feed.Extra>
            <Feed.Content>
              <Grid columns={2}>
                <Grid.Column>
                  {offer.price}USD
                </Grid.Column>
                <Grid.Column>
                  <Icon name='handshake outline' onClick={handleTakeOffer}/>
                </Grid.Column>
              </Grid>
            </Feed.Content>
          </Feed.Extra>
        </Feed.Content>
      </Feed.Event>
    );
};

export default OfferEvent;
