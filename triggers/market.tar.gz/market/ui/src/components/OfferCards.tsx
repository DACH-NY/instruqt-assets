import React from 'react'
import {Card} from 'semantic-ui-react'
import {OfferCard} from './OfferCard'
import * as market from '@daml.js/market'
import {CreateEvent} from '@daml/ledger'
import { userContext } from './App'
import { Party } from '@daml/types'

type Props = {
  partyToAlias: Map<Party, string>;
};


const OfferCards: React.FC<Props> = ({partyToAlias}) =>
{
  const party = userContext.useParty();
  const sellOffers = userContext.useStreamQuery(market.Market.SellOffer, () => ({}), [party]);
  const ledger = userContext.useLedger();
  const handleTakeOfferRequest = async (sellOffer: CreateEvent<market.Market.SellOffer>) => {
    await ledger.exerciseByKey(market.Market.User.TakeSellOffer, party, {offer: sellOffer.contractId});
    alert('You bought ' + sellOffer.payload.title + '!');
  }

  return (
    <Card.Group>
        {sellOffers.contracts.map(sellOffer =>
          <OfferCard
            offer={sellOffer.payload}
            handleTakeOffer={() => handleTakeOfferRequest(sellOffer)}
            partyToAlias={partyToAlias}
          >
          </OfferCard>
        )}
    </Card.Group>
  )
}

export default OfferCards;
